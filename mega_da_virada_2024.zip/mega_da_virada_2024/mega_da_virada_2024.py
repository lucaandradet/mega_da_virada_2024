################################################################################################
# Nome do projeto: Mega da virada 2024                                                         #
# Desenvolvedor: Lucas Andrade                                                                 #
# Data: 31/12/2024                                                                             #
# Objetivo do projeto: Esse projeto utilizando métodos preditivos foi                          #
#                      idealizado para realizar a análise dos últimos 15 anos dos jogos da     #
#                      mega da virada e verificar os números que mais e menos saíram, assim,   #
#                      gerando o resultado de 3 possíveis jogos vencedores.                    #
################################################################################################

import random
from collections import Counter

# Dados fornecidos dos últimos 15 anos (Últimos jogos sorteados de 2009 à 2023)
historico = [
    [10, 27, 40, 46, 49, 58],
    [2, 10, 34, 37, 43, 50],
    [3, 4, 29, 36, 45, 55],
    [14, 32, 33, 36, 41, 52],
    [20, 30, 36, 38, 47, 53],
    [1, 5, 11, 16, 20, 56],
    [2, 18, 31, 42, 51, 56],
    [5, 11, 22, 24, 51, 53],
    [3, 6, 10, 17, 34, 37],
    [5, 10, 12, 18, 25, 33],
    [3, 35, 38, 40, 57, 58],
    [17, 20, 22, 35, 41, 42],
    [12, 15, 23, 32, 33, 46],
    [4, 5, 10, 34, 58, 59],
    [21, 24, 33, 41, 48, 56]
]

# Pesos de frequência
pesos = {
    5: 5,  # Muito frequente
    4: 4,  # Frequente
    3: 3,  # Moderado
    2: 2,  # Pouco frequente
    1: 1,  # Raro
}

# Frequências dos números
# Os números não contidos nessa frequência nunca foram sorteados
frequencias = {
    10: 5, # Números que saíram 5 vezes
    5: 4, 33: 4, # Números que saíram 4 vezes
    3: 3, 20: 3, 34: 3, 36: 3, 58: 3, 41: 3, 56: 3, # Números que saíram 3 vezes
    2: 2, 4: 2, 11: 2, 12: 2, 17: 2, 18: 2, 22: 2, 32: 2, 35: 2, 37: 2, 38: 2, 40: 2, 42: 2, 46: 2, 51: 2, 53: 2, # Números que saíram 2 vezes
    1: 1, 6: 1, 14: 1, 15: 1, 16: 1, 21: 1, 23: 1, 25: 1, 27: 1, 29: 1, 30: 1, 31: 1, 43: 1, 45: 1, 47: 1, 48: 1, 49: 1, 50: 1, 52: 1, 55: 1, 57: 1, 59: 1 # Números que saíram 1 vez
}

# Gerar um jogo baseado nos pesos
def gerar_jogo(frequencias, n=6):
    numeros = list(frequencias.keys())
    pesos = [frequencias[num] for num in numeros]
    return random.choices(numeros, weights=pesos, k=n)

# Gerar 3 jogos
jogos = [sorted(gerar_jogo(frequencias)) for _ in range(3)]

# Exibir os jogos gerados
for i, jogo in enumerate(jogos, 1):
    print(f"Jogo {i}: {jogo}")
    print(f"")